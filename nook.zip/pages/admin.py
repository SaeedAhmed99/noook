from django.contrib import admin
from .models import Category, About, Addwork, Blog, CommentsBlog, Contect

admin.site.register(Category)
admin.site.register(About)
admin.site.register(Addwork)
admin.site.register(Blog)
admin.site.register(CommentsBlog)
admin.site.register(Contect)